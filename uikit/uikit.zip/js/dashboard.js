$(document).ready(function()
{
    $(".reset").click(function()
    {
        console.log("RESET DONE");
    });
});